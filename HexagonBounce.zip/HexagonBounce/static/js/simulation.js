class PhysicsSimulation {
    constructor() {
        this.setupMenuControls();
    }

    setupMenuControls() {
        const startButton = document.getElementById('startButton');
        const mainMenu = document.getElementById('mainMenu');
        const simulationContainer = document.querySelector('.simulation-container');

        startButton.addEventListener('click', () => {
            mainMenu.classList.add('fade-out');
            simulationContainer.style.display = 'block';
            this.initializeSimulation();
        });
    }

    initializeSimulation() {
        this.canvas = document.getElementById('simulationCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.bounceCount = 0;
        this.bounceCounter = document.getElementById('bounceCount');

        // Canvas setup
        this.canvas.width = 600;
        this.canvas.height = 600;

        // Physics controls
        this.gravityEnabled = true;
        this.frictionEnabled = true;
        this.chaosMode = false;
        this.chaosInterval = null;
        this.setupControls();

        // Physics constants
        this.gravity = 0.5;
        this.friction = 0.99;
        this.rotationSpeed = 0.005;
        this.rotation = 0;
        this.sides = 6;

        // Multiple balls support
        this.balls = [{
            x: this.canvas.width / 2,
            y: this.canvas.height / 3,
            radius: 15,
            velocityX: 3,
            velocityY: 0,
            color: this.getRandomColor()
        }];

        // Shape properties
        this.shapeRadius = 250;
        this.shapeColor = '#4CAF50';
        this.randomColorsEnabled = true;

        // Start animation
        this.animate();
    }

    setupControls() {
        // Basic controls
        const gravityBtn = document.getElementById('gravityToggle');
        const frictionBtn = document.getElementById('frictionToggle');

        gravityBtn.addEventListener('click', () => {
            this.gravityEnabled = !this.gravityEnabled;
            gravityBtn.classList.toggle('active');
            gravityBtn.textContent = `Gravity: ${this.gravityEnabled ? 'ON' : 'OFF'}`;
            gravityBtn.dataset.active = this.gravityEnabled;
        });

        frictionBtn.addEventListener('click', () => {
            this.frictionEnabled = !this.frictionEnabled;
            frictionBtn.classList.toggle('active');
            frictionBtn.textContent = `Friction: ${this.frictionEnabled ? 'ON' : 'OFF'}`;
            frictionBtn.dataset.active = this.frictionEnabled;
        });

        // Shape controls
        document.getElementById('shapeSelect').addEventListener('change', (e) => {
            this.sides = parseInt(e.target.value);
        });

        // Ball controls
        document.getElementById('ballCount').addEventListener('input', (e) => {
            const count = parseInt(e.target.value);
            document.getElementById('ballCountValue').textContent = count;
            this.updateBallCount(count);
        });

        document.getElementById('ballSize').addEventListener('input', (e) => {
            const size = parseInt(e.target.value);
            document.getElementById('ballSizeValue').textContent = size;
            this.balls.forEach(ball => ball.radius = size);
        });

        // Physics controls
        document.getElementById('gravityStrength').addEventListener('input', (e) => {
            this.gravity = parseFloat(e.target.value);
            document.getElementById('gravityValue').textContent = this.gravity.toFixed(1);
        });

        document.getElementById('rotationSpeed').addEventListener('input', (e) => {
            this.rotationSpeed = parseFloat(e.target.value) * 0.01;
            document.getElementById('rotationValue').textContent = (this.rotationSpeed * 100).toFixed(1);
        });

        // Visual controls
        document.getElementById('randomColors').addEventListener('change', (e) => {
            this.randomColorsEnabled = e.target.checked;
        });

        document.getElementById('shapeColor').addEventListener('input', (e) => {
            this.shapeColor = e.target.value;
        });

        // Add chaos mode toggle
        const chaosBtn = document.getElementById('chaosToggle');
        chaosBtn.addEventListener('click', () => {
            this.chaosMode = !this.chaosMode;
            chaosBtn.classList.toggle('active');

            if (this.chaosMode) {
                this.startChaosMode();
            } else {
                this.stopChaosMode();
            }
        });
    }

    startChaosMode() {
        this.chaosInterval = setInterval(() => {
            // Randomize gravity
            this.gravity = Math.random() * 2 - 1; // Random value between -1 and 1
            document.getElementById('gravityValue').textContent = Math.abs(this.gravity).toFixed(1);
            document.getElementById('gravityStrength').value = Math.abs(this.gravity);

            // Randomize rotation
            this.rotationSpeed = (Math.random() * 4 - 2) * 0.01; // Random between -0.02 and 0.02
            document.getElementById('rotationValue').textContent = (Math.abs(this.rotationSpeed) * 100).toFixed(1);
            document.getElementById('rotationSpeed').value = Math.abs(this.rotationSpeed) * 100;

            // Random shape size
            this.shapeRadius = 150 + Math.random() * 200; // Random between 150 and 350

            // Add random impulses to balls
            this.balls.forEach(ball => {
                ball.velocityX += (Math.random() * 2 - 1) * 2;
                ball.velocityY += (Math.random() * 2 - 1) * 2;
                if (this.randomColorsEnabled) {
                    ball.color = this.getRandomColor();
                }
            });

            // Random shape
            const shapes = [4, 5, 6, 8];
            this.sides = shapes[Math.floor(Math.random() * shapes.length)];
            document.getElementById('shapeSelect').value = this.sides;

        }, 2000); // Change parameters every 2 seconds
    }

    stopChaosMode() {
        clearInterval(this.chaosInterval);
        // Reset to default values
        this.gravity = 0.5;
        this.rotationSpeed = 0.005;
        this.shapeRadius = 250;
        document.getElementById('gravityValue').textContent = this.gravity.toFixed(1);
        document.getElementById('rotationValue').textContent = (this.rotationSpeed * 100).toFixed(1);
        document.getElementById('gravityStrength').value = this.gravity;
        document.getElementById('rotationSpeed').value = this.rotationSpeed * 100;
    }

    updateBallCount(count) {
        while (this.balls.length < count) {
            this.balls.push({
                x: this.canvas.width / 2,
                y: this.canvas.height / 3,
                radius: this.balls[0].radius,
                velocityX: Math.random() * 6 - 3,
                velocityY: 0,
                color: this.getRandomColor()
            });
        }
        this.balls = this.balls.slice(0, count);
    }

    getRandomColor() {
        const colors = ['#4CAF50', '#2196F3', '#9C27B0', '#FF9800', '#E91E63', '#00BCD4'];
        return colors[Math.floor(Math.random() * colors.length)];
    }

    drawShape() {
        this.ctx.save();
        this.ctx.translate(this.canvas.width / 2, this.canvas.height / 2);
        this.ctx.rotate(this.rotation);

        this.ctx.beginPath();
        for (let i = 0; i < this.sides; i++) {
            const angle = (i * Math.PI * 2) / this.sides;
            const x = this.shapeRadius * Math.cos(angle);
            const y = this.shapeRadius * Math.sin(angle);
            if (i === 0) {
                this.ctx.moveTo(x, y);
            } else {
                this.ctx.lineTo(x, y);
            }
        }
        this.ctx.closePath();
        this.ctx.strokeStyle = this.shapeColor;
        this.ctx.lineWidth = 3;
        this.ctx.stroke();
        this.ctx.restore();
    }

    drawBalls() {
        this.balls.forEach(ball => {
            this.ctx.beginPath();
            this.ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
            this.ctx.fillStyle = ball.color;
            this.ctx.fill();
            this.ctx.closePath();
        });
    }

    checkCollision(ball) {
        const ballPos = {
            x: ball.x - this.canvas.width / 2,
            y: ball.y - this.canvas.height / 2
        };

        // Rotate ball position opposite to shape rotation
        const rotatedBallPos = {
            x: ballPos.x * Math.cos(-this.rotation) - ballPos.y * Math.sin(-this.rotation),
            y: ballPos.x * Math.sin(-this.rotation) + ballPos.y * Math.cos(-this.rotation)
        };

        // Get shape vertices
        const vertices = [];
        for (let i = 0; i < this.sides; i++) {
            const angle = (i * Math.PI * 2) / this.sides;
            vertices.push({
                x: this.shapeRadius * Math.cos(angle),
                y: this.shapeRadius * Math.sin(angle)
            });
        }

        // Check collision with each edge
        let collision = false;
        let closestEdgeNormal = { x: 0, y: 0 };
        let minDist = Infinity;

        for (let i = 0; i < this.sides; i++) {
            const v1 = vertices[i];
            const v2 = vertices[(i + 1) % this.sides];

            // Calculate edge vector
            const edge = {
                x: v2.x - v1.x,
                y: v2.y - v1.y
            };

            // Calculate normal vector (perpendicular to edge)
            const normal = {
                x: -edge.y,
                y: edge.x
            };
            const normalLength = Math.sqrt(normal.x * normal.x + normal.y * normal.y);
            normal.x /= normalLength;
            normal.y /= normalLength;

            // Calculate distance from ball to edge
            const dist = (rotatedBallPos.x - v1.x) * normal.x + (rotatedBallPos.y - v1.y) * normal.y;

            if (Math.abs(dist) < ball.radius) {
                // Project ball position onto edge line
                const proj = {
                    x: rotatedBallPos.x - dist * normal.x,
                    y: rotatedBallPos.y - dist * normal.y
                };

                // Check if projection falls on the edge segment
                const edgeLength = Math.sqrt(edge.x * edge.x + edge.y * edge.y);
                const t = ((proj.x - v1.x) * edge.x + (proj.y - v1.y) * edge.y) / (edgeLength * edgeLength);

                if (t >= 0 && t <= 1) {
                    collision = true;
                    if (Math.abs(dist) < Math.abs(minDist)) {
                        minDist = dist;
                        closestEdgeNormal = normal;
                    }
                }
            }
        }

        if (collision) {
            // Rotate velocity vector
            const rotatedVelocity = {
                x: ball.velocityX * Math.cos(-this.rotation) - ball.velocityY * Math.sin(-this.rotation),
                y: ball.velocityX * Math.sin(-this.rotation) + ball.velocityY * Math.cos(-this.rotation)
            };

            // Reflect velocity with minimal energy loss when friction is off
            const restitution = this.frictionEnabled ? this.friction : 0.999;
            const dot = 2 * (rotatedVelocity.x * closestEdgeNormal.x + rotatedVelocity.y * closestEdgeNormal.y);
            rotatedVelocity.x = (rotatedVelocity.x - dot * closestEdgeNormal.x) * restitution;
            rotatedVelocity.y = (rotatedVelocity.y - dot * closestEdgeNormal.y) * restitution;

            // Rotate velocity back
            ball.velocityX = rotatedVelocity.x * Math.cos(this.rotation) - rotatedVelocity.y * Math.sin(this.rotation);
            ball.velocityY = rotatedVelocity.x * Math.sin(this.rotation) + rotatedVelocity.y * Math.cos(this.rotation);

            // Prevent sticking by moving ball out of collision
            const pushOut = ball.radius - Math.abs(minDist);
            ball.x += closestEdgeNormal.x * pushOut * Math.cos(this.rotation) - closestEdgeNormal.y * pushOut * Math.sin(this.rotation);
            ball.y += closestEdgeNormal.x * pushOut * Math.sin(this.rotation) + closestEdgeNormal.y * pushOut * Math.cos(this.rotation);

            // Update bounce count and colors
            this.bounceCount++;
            this.bounceCounter.textContent = this.bounceCount;
            if (this.randomColorsEnabled) {
                ball.color = this.getRandomColor();
            }
        }
    }

    update() {
        // Update balls
        this.balls.forEach(ball => {
            if (this.gravityEnabled) {
                ball.velocityY += this.gravity;
            }
            ball.x += ball.velocityX;
            ball.y += ball.velocityY;

            // Check for collisions
            this.checkCollision(ball);
        });

        // Rotate shape
        this.rotation += this.rotationSpeed;
    }

    draw() {
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        // Draw simulation elements
        this.drawShape();
        this.drawBalls();
    }

    animate() {
        this.update();
        this.draw();
        requestAnimationFrame(() => this.animate());
    }
}

// Start simulation when window loads
window.addEventListener('load', () => {
    new PhysicsSimulation();
});